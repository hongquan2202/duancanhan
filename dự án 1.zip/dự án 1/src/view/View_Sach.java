/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import javax.swing.table.DefaultTableModel;
import Repositories.Repositories_Sach;
import Model.Moder_Sach;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author TUAN VU
 */
public class View_Sach extends javax.swing.JFrame {

    private DefaultTableModel mol = new DefaultTableModel();
    private Repositories_Sach rp = new Repositories_Sach();
    private int i = -1;

    /**
     * Creates new form View_Sach
     */
    public View_Sach() {
        initComponents();
        this.fillTable(rp.getAll());
        i = rp.getAll().size();
        this.showData(0);
    }

    public void fillTable(ArrayList<Moder_Sach> list) {
        mol = (DefaultTableModel) tblSach.getModel();
        mol.setRowCount(0);
        for (Moder_Sach moder_Sach : list) {
            mol.addRow(moder_Sach.toDaTaRow());
        }
    }

    public void showData(int i) {
        txtMaSach.setText(tblSach.getValueAt(i, 0).toString());
        txtTenSach.setText(tblSach.getValueAt(i, 1).toString());
        txtMaTacGia.setText(tblSach.getValueAt(i, 2).toString());
        txtMaTheLoai.setText(tblSach.getValueAt(i, 3).toString());
        txtMaNPH.setText(tblSach.getValueAt(i, 4).toString());
        txtSoLuong.setText(tblSach.getValueAt(i, 5).toString());
        txtGiaThue.setText(tblSach.getValueAt(i, 6).toString());
        txtViTri.setText(tblSach.getValueAt(i, 7).toString());
    }

    public Moder_Sach readForm() {
        int maSach;
        String tenSach;
        int maTacGia;
        int maTheLoai;
        int maNhaPhatHanh;
        int soLuongTon;
        float giaThue;
        String viTri;
         maSach = Integer.parseInt(txtMaSach.getText().trim());
        if (txtMaSach.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Mã chưa nhập");
            return null;
        } else {
            try {
                maSach = Integer.parseInt(txtMaSach.getText());
                if (maSach < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Mã cưa đúng");
                    txtMaSach.requestFocus();
                    return null;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Mã ko phải số");
                txtMaSach.requestFocus();
                return null;
    }
        }
        tenSach=txtTenSach.getText().trim();
        if (tenSach.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn chưa nhập dữ liệu!");
            txtTenSach.requestFocus();
            return null;
        }
           maTacGia = Integer.parseInt(txtMaTacGia.getText().trim());
        if (txtMaTacGia.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Mã chưa nhập");
            return null;
        } else {
            try {
                maSach = Integer.parseInt(txtMaSach.getText());
                if (maTacGia < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Mã cưa đúng");
                    txtMaTacGia.requestFocus();
                    return null;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Mã ko phải số");
                txtMaTacGia.requestFocus();
                return null;
    }
        }
           maTheLoai = Integer.parseInt(txtMaTheLoai.getText().trim());
        if (txtMaTheLoai.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Mã chưa nhập");
            return null;
        } else {
            try {
                maTheLoai = Integer.parseInt(txtMaTheLoai.getText());
                if (maTheLoai < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Mã cưa đúng");
                    txtMaTheLoai.requestFocus();
                    return null;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Mã ko phải số");
                txtMaTheLoai.requestFocus();
                return null;
    }
        }
           maNhaPhatHanh = Integer.parseInt(txtMaNPH.getText().trim());
        if (txtMaNPH.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Mã chưa nhập");
            return null;
        } else {
            try {
                maNhaPhatHanh = Integer.parseInt(txtMaNPH.getText());
                if (maSach < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Mã cưa đúng");
                    txtMaNPH.requestFocus();
                    return null;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Mã ko phải số");
                txtMaNPH.requestFocus();
                return null;
    }
        }
           soLuongTon= Integer.parseInt(txtSoLuong.getText().trim());
        if (txtSoLuong.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Mã chưa nhập");
            return null;
        } else {
            try {
                soLuongTon = Integer.parseInt(txtMaSach.getText());
                if (soLuongTon < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Mã cưa đúng");
                    txtSoLuong.requestFocus();
                    return null;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Mã ko phải số");
                txtSoLuong.requestFocus();
                return null;
    }
        }
         giaThue = Float.parseFloat(txtGiaThue.getText().trim());
        if (txtGiaThue.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Điểm chưa nhập");
            return null;
        } else {
            try {
               giaThue = Float.parseFloat(txtGiaThue.getText());
                if (giaThue < 0) {
                    JOptionPane.showMessageDialog(rootPane, "Điểm cưa đúng");
                    txtGiaThue.requestFocus();
                    return null;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, "Điểm ko phải số");
                txtGiaThue.requestFocus();
                return null;
    }
        }
          viTri=txtViTri.getText().trim();
        if (viTri.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn chưa nhập dữ liệu!");
            txtViTri.requestFocus();
            return null;
        }
        return new Moder_Sach(maSach, tenSach, maTacGia, maTheLoai, maNhaPhatHanh, soLuongTon, giaThue, viTri);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnSach = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtMaSach = new javax.swing.JTextField();
        txtMaTheLoai = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        txtMaNPH = new javax.swing.JTextField();
        txtViTri = new javax.swing.JTextField();
        txtGiaThue = new javax.swing.JTextField();
        txtMaTacGia = new javax.swing.JTextField();
        txtTenSach = new javax.swing.JTextField();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSach = new javax.swing.JTable();
        btnTimKiem = new javax.swing.JButton();
        txtTimKiem = new javax.swing.JTextField();
        btnSapxep = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnSach.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setText("Mã Tác Giả");

        jLabel3.setText("Tên Sách");

        jLabel4.setText("Mã Sách ");

        jLabel5.setText("Mã Thể Loại");

        jLabel6.setText("Mã Thể Loại");

        jLabel7.setText("Mã Nhà Phát Hành");

        jLabel8.setText("Số Lượng Tồn");

        jLabel9.setText("Giá Thuê");

        jLabel10.setText("Vị Trí");

        txtMaNPH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMaNPHActionPerformed(evt);
            }
        });

        txtGiaThue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGiaThueActionPerformed(evt);
            }
        });

        txtMaTacGia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMaTacGiaActionPerformed(evt);
            }
        });

        btnThem.setText("Thêm");
        btnThem.setMaximumSize(new java.awt.Dimension(80, 23));
        btnThem.setMinimumSize(new java.awt.Dimension(80, 23));
        btnThem.setPreferredSize(new java.awt.Dimension(80, 23));
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sửa");
        btnSua.setMaximumSize(new java.awt.Dimension(80, 23));
        btnSua.setMinimumSize(new java.awt.Dimension(80, 23));
        btnSua.setPreferredSize(new java.awt.Dimension(80, 23));
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("Xóa");
        btnXoa.setMaximumSize(new java.awt.Dimension(80, 23));
        btnXoa.setMinimumSize(new java.awt.Dimension(80, 23));
        btnXoa.setPreferredSize(new java.awt.Dimension(80, 23));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        jButton1.setText("Làm Mới");
        jButton1.setMaximumSize(new java.awt.Dimension(80, 23));
        jButton1.setMinimumSize(new java.awt.Dimension(80, 23));
        jButton1.setPreferredSize(new java.awt.Dimension(80, 23));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        tblSach.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã Sách", "Tên Sách", "Mã Tác Giả", "Mã Thể Loại", "Mã Nhà Phát Hành", "Số Lượng Tồn", "Giá Thuê", "Vị Trí"
            }
        ));
        tblSach.setRowHeight(25);
        tblSach.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSachMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSach);

        btnTimKiem.setText("Tìm Kiếm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        txtTimKiem.setBorder(null);
        txtTimKiem.setMinimumSize(new java.awt.Dimension(500, 20));

        btnSapxep.setText("Sắp xếp lại");
        btnSapxep.setMaximumSize(new java.awt.Dimension(80, 23));
        btnSapxep.setMinimumSize(new java.awt.Dimension(80, 23));
        btnSapxep.setPreferredSize(new java.awt.Dimension(80, 23));
        btnSapxep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSapxepActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Sách");

        javax.swing.GroupLayout pnSachLayout = new javax.swing.GroupLayout(pnSach);
        pnSach.setLayout(pnSachLayout);
        pnSachLayout.setHorizontalGroup(
            pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnSachLayout.createSequentialGroup()
                .addGap(338, 338, 338)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnSachLayout.createSequentialGroup()
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createSequentialGroup()
                        .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnSachLayout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btnTimKiem)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)))
                        .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTimKiem, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 621, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtMaSach, javax.swing.GroupLayout.PREFERRED_SIZE, 621, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtTenSach, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 621, Short.MAX_VALUE)
                                    .addComponent(txtMaTacGia, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtMaTheLoai, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtMaNPH, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtSoLuong, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtGiaThue, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtViTri, javax.swing.GroupLayout.Alignment.LEADING))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnSachLayout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(btnSapxep, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnXoa, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                    .addComponent(btnSua, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addContainerGap())
        );
        pnSachLayout.setVerticalGroup(
            pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnSachLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnTimKiem)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSapxep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaSach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTenSach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMaTacGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnXoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaTheLoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(10, 10, 10)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaNPH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(btnSua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(14, 14, 14)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtGiaThue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnSachLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnSachLayout.createSequentialGroup()
                        .addGroup(pnSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtViTri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnSach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(269, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnSach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtMaTacGiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMaTacGiaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMaTacGiaActionPerformed

    private void txtGiaThueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGiaThueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGiaThueActionPerformed

    private void txtMaNPHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMaNPHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMaNPHActionPerformed

    private void tblSachMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSachMouseClicked
        // TODO add your handling code here:
        i = tblSach.getSelectedRow();
        this.showData(i);
    }//GEN-LAST:event_tblSachMouseClicked

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
           if(this.readForm()==null){
            JOptionPane.showMessageDialog(this,"Thêm thất bại");
        }else{
            if(rp.them(this.readForm())>0){
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                this.fillTable(rp.getAll());
            }else{
                JOptionPane.showMessageDialog(this, "Không thêm được");
            } 
            
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
    
          if(this.readForm()==null){
            JOptionPane.showMessageDialog(this,"Sửa thất bại");
        }else{
            if(rp.sua(this.readForm())>0){
                JOptionPane.showMessageDialog(this, "Sửa thành công");
                this.fillTable(rp.getAll());
            }else{
                JOptionPane.showMessageDialog(this, "Không sửa được");
            } 
            
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        txtMaSach.setText("");
        txtTenSach.setText("");
        txtMaTacGia.setText("");
        txtMaTheLoai.setText("");
        txtMaNPH.setText("");
        txtSoLuong.setText("");
        txtTimKiem.setText("");
        txtGiaThue.setText("");
        txtViTri.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        // TODO add your handling code here:
       String tenCanTim=txtTimKiem.getText().trim();
        if (rp.timKiem(tenCanTim).isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Không tìm thấy");
        } else{
            this.fillTable(rp.timKiem(tenCanTim));
            JOptionPane.showMessageDialog(rootPane, "Danh Sách Cần Tìm");
        }
    
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        // TODO add your handling code here:
         if(this.readForm()==null){
            JOptionPane.showMessageDialog(this,"Xóa thất bại");
        }else{
            if(rp.xoa(this.readForm())>0){
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                this.fillTable(rp.getAll());
            }else{
                JOptionPane.showMessageDialog(this, "Không xóa được");
            } 
            
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnSapxepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSapxepActionPerformed
        // TODO add your handling code here:
        this.fillTable(rp.getAll());
    }//GEN-LAST:event_btnSapxepActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View_Sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View_Sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View_Sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View_Sach.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View_Sach().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSapxep;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JPanel pnSach;
    private javax.swing.JTable tblSach;
    private javax.swing.JTextField txtGiaThue;
    private javax.swing.JTextField txtMaNPH;
    private javax.swing.JTextField txtMaSach;
    private javax.swing.JTextField txtMaTacGia;
    private javax.swing.JTextField txtMaTheLoai;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSach;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtViTri;
    // End of variables declaration//GEN-END:variables
}
