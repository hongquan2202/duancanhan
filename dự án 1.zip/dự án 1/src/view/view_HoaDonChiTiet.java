/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;
import Model.mo_HoaDonChiTiet;
import Repositories.repo_HoaDonChiTiet;
import java.awt.Color;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import utils.ConnectDB;
/**
 *
 * @author hungl
 */
public class view_HoaDonChiTiet extends javax.swing.JFrame {

    /**
     * Creates new form view_HoaDonChiTiet
     */
    
    private DefaultTableModel mol = new DefaultTableModel();
    public repo_HoaDonChiTiet repo = new repo_HoaDonChiTiet();
    public Connection con = ConnectDB.getConnection();
    public ResultSet rs = null;
    public PreparedStatement ps = null;
    public String sql = null;
    private ArrayList<mo_HoaDonChiTiet> arr = new ArrayList<>();
    public view_HoaDonChiTiet() {
        initComponents();
        loadData();
    }
    public void loadData(){
        arr =repo.duyetSql();
        this.fillToTable();
        System.out.println(arr.size());
    }
    public void fillToTable(){
        mol=(DefaultTableModel) tb.getModel();
        mol.setNumRows(0);
        for (mo_HoaDonChiTiet m : arr) {
        Object[] row = {m.getMaPhieuMuonChiTiet(),m.getMaSach(),m.getMaPhieuMuon(),m.getNgayMuon(),m.getNgayTra(),m.getTongTien(),m.getTrangThai()==1?"da thanh toan":"chua thanh toan"};
        mol.addRow(row);   
    }
        tb.setModel(mol);
}
    

    public int haingay(){        
        SimpleDateFormat sp = new SimpleDateFormat("yyyy-MM-dd");
        sp.setLenient(false);
        String a = nt.getText();
        String b = nm.getText();
        long diffDays = 0;
        try {
            // Chuyển chuỗi thành đối tượng Date
            java.util.Date date = sp.parse(a);
            java.util.Date date1 = sp.parse(b);
            long diffMillis = date.getTime() - date1.getTime();
            
            // Chuyển đổi kết quả từ millisecond sang ngày
            diffDays = diffMillis / (24 * 60 * 60 * 1000);
            
            // In kết quả
            System.out.println(diffDays + " ngày.");
            if(diffDays<0){
                return 0;
            }
            // In kết quả
        } catch (Exception e) {
            System.out.println("nhap ddungs ddinhj dnag");
        }
        return (int) diffDays;
    }
    public void them(){
        float giaTien = haingay();
        if(giaTien == 0){
            JOptionPane.showMessageDialog(rootPane,"Kiem tra lai ngay");
            return;
        }
                try{
                    
                    String queryUpdate = "Insert into PhieuMuonChiTiet(maPhieuMuonChiTiet, maPhieuMuon, maSach, ngayMuon,ngayTra,giaTien,trangThai) values (?,?,?,?,?,?,?)";
                    PreparedStatement ps = con.prepareStatement(queryUpdate);
                    ps.setString(1,mpmct.getText());
                    ps.setString(2,ms.getText());
                    ps.setString(3,mpm.getText());
                    ps.setString(4,nm.getText());
                    ps.setString(5,nt.getText());
                    ps.setFloat(6,giaTien);
                    if(a.isSelected()){
                        ps.setInt(7, 1);
                    }else{
                        ps.setInt(7, 0);
                    }        
                          
                ps.execute();
                
            }catch(SQLException ex){
                JOptionPane.showMessageDialog(rootPane,"ma sach hoac phieu muon khong ton tai vui long kiem tra lai");
            }
                loadData(); 
    }
    public void xoa(){
        try{
                    
                    String queryUpdate = "Delete PhieuMuonChiTiet where maPhieuMuonChiTiet = ?";
                    PreparedStatement ps = con.prepareStatement(queryUpdate);
                    ps.setString(1,mpmct.getText());                    
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(rootPane,"xoa thanh cong");
                    mpmct.setText("");
                    mpm.setText("");
                    ms.setText("");
                    nm.setText("");
                    nt.setText("");
                    tt.setText("");
                    a.setSelected(false);
                    loadData();
                   
            }catch(SQLException ex){
                JOptionPane.showMessageDialog(rootPane,"ma phieu muon da ton tai ");
            }
        loadData();
        
    }
    public void update(){
        float giaTien = haingay();
        if(giaTien == 0){
            JOptionPane.showMessageDialog(rootPane,"Kiem tra lai ngay");
            return;
        }
        try{
                    
                    String queryUpdate = "update PhieuMuonChiTiet set maPhieuMuon = ?, maSach = ? , ngayMuon = ?,ngayTra = ? ,giaTien = ?,trangThai = ? where maPhieuMuonChiTiet = ?";
                    PreparedStatement ps = con.prepareStatement(queryUpdate);
                    ps.setString(1,ms.getText());
                    ps.setString(2,mpm.getText());
                    ps.setString(3,nm.getText());
                    ps.setString(4,nt.getText());
                    ps.setFloat(5,giaTien);
                    if(a.isSelected()){
                        ps.setInt(6, 1);
                    }else{
                        ps.setInt(6, 0);
                    }   
                    ps.setString(7,mpmct.getText());
                          
                ps.execute();
                                 
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(rootPane,"sua thanh cong");
                   
            }catch(SQLException ex){
                JOptionPane.showMessageDialog(rootPane,"ma phieu muon chi tiet khong ton tai");
            }
        loadData();
    }
    public void sapxep(){
        Collections.sort(arr,new Comparator<mo_HoaDonChiTiet>(){
            @Override
            public int compare(mo_HoaDonChiTiet o1, mo_HoaDonChiTiet o2) {
               return Float.compare(o2.getTongTien(), o1.getTongTien());
            }
        });
        fillToTable();
    }
    
    
        /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jButton7 = new javax.swing.JButton();
        p = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        mpmct = new javax.swing.JTextField();
        ms = new javax.swing.JTextField();
        mpm = new javax.swing.JTextField();
        nm = new javax.swing.JTextField();
        nt = new javax.swing.JTextField();
        tt = new javax.swing.JTextField();
        a = new javax.swing.JRadioButton();
        b = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb = new javax.swing.JTable();
        jButton6 = new javax.swing.JButton();
        tk = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        cb = new javax.swing.JComboBox<>();

        jButton7.setText("jButton7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        p.setBackground(new java.awt.Color(204, 204, 204));
        p.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setText("Mã Phiếu Mượn Chi Tiết");

        jLabel3.setText("Mã Sách");

        jLabel4.setText("Mã Phiêú mượn");

        jLabel5.setText("Ngày Mượn");

        jLabel6.setText("Ngày Trả");

        jLabel7.setText("Tổng Tiền");

        jLabel8.setText("Trạng thái");

        ms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                msActionPerformed(evt);
            }
        });

        nm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nmActionPerformed(evt);
            }
        });

        tt.setEnabled(false);

        buttonGroup1.add(a);
        a.setText("Đã Thanh Toán");

        buttonGroup1.add(b);
        b.setText("Chưa Thanh Toán");

        jButton1.setText("Thêm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Sửa");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Xóa");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Đặt Lại");

        tb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã Phiếu mượn chi tiết", "Mã sách", "Mã Phiếu mượn", "Ngày Mượn", "Ngày Trả", "Tổng tiền ", "Trạng thái"
            }
        ));
        tb.setFocusable(false);
        tb.setRowHeight(25);
        tb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb);

        jButton6.setText("Tìm Kiếm");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        tk.setForeground(new java.awt.Color(204, 204, 204));
        tk.setText("Nhập vào phiếu mượn chi tiết");
        tk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tkMouseClicked(evt);
            }
        });
        tk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tkActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Phiếu Mượn Chi Tiết");

        jButton9.setText("Tổng Tiền");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        cb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mặc Định", "Theo tổng tiền tăng dần", "Theo tổng tiền giảm dần", "Theo Trạng Thái" }));
        cb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pLayout = new javax.swing.GroupLayout(p);
        p.setLayout(pLayout);
        pLayout.setHorizontalGroup(
            pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pLayout.createSequentialGroup()
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(pLayout.createSequentialGroup()
                        .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pLayout.createSequentialGroup()
                                .addGap(288, 288, 288)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pLayout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(b, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(a, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(mpmct, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                                        .addComponent(ms)
                                        .addComponent(mpm)
                                        .addComponent(nm)
                                        .addComponent(nt)
                                        .addComponent(tt))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                                    .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cb, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton9)))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pLayout.createSequentialGroup()
                                    .addGap(147, 147, 147)
                                    .addComponent(jButton6)
                                    .addGap(34, 34, 34)
                                    .addComponent(tk, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 134, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pLayout.setVerticalGroup(
            pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(mpmct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(mpm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(20, 20, 20)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(nt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4))
                .addGap(18, 18, 18)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9))
                .addGap(18, 18, 18)
                .addGroup(pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(a)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(b)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(p, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(p, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void msActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_msActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_msActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         SimpleDateFormat sp = new SimpleDateFormat("yyyy-MM-dd");
        sp.setLenient(false);
        String a = nm.getText();
        String b = nt.getText();
        try {
            // Chuyển chuỗi thành đối tượng Date
            java.util.Date date = sp.parse(a);
            java.util.Date date1 = sp.parse(b);
            String formattedDate = sp.format(date);
            String formattedDate1 = sp.format(date1);
            System.out.println(formattedDate + " ngày.");
            them();
            // In kết quả
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane,"Vui long nhap ngay thang hop le");
        }
                  
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        xoa(); 
        
        
        
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        update();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        int d = 0;
        for(int i = 0;i<arr.size();i++){
            if(tk.getText().equals(arr.get(i).getMaPhieuMuonChiTiet())){
                mpmct.setText(arr.get(i).getMaPhieuMuonChiTiet());
                 mpm.setText(arr.get(i).getMaPhieuMuon());
                 ms.setText(arr.get(i).getMaSach());
                 nm.setText(arr.get(i).getNgayMuon());
                 nt.setText(arr.get(i).getNgayTra());
                 tt.setText(String.valueOf(arr.get(i).getTongTien()));
                 if(arr.get(i).getTrangThai()==1){
                     a.setSelected(true);
                 }else{
                     b.setSelected(true);
                 }
                 d = 1;
            }
        }
        if(d == 0){
            JOptionPane.showMessageDialog(rootPane,"Mã không tồn tại");
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void tkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tkActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        tt.setText(String.valueOf(haingay()*1000)+" đồng");
        
    }//GEN-LAST:event_jButton9ActionPerformed

    private void cbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbActionPerformed

       if(cb.getSelectedIndex()==0){
           loadData();
       }else if(cb.getSelectedIndex() == 1){
            Collections.sort(arr,new Comparator<mo_HoaDonChiTiet>(){
            @Override
            public int compare(mo_HoaDonChiTiet o1, mo_HoaDonChiTiet o2) {
               if(o1.getTongTien()>o2.getTongTien()){
                   return 1;
               }else{
                   return -1;
               }
            }
        });
        fillToTable();
       }else if(cb.getSelectedIndex() == 2){
           Collections.sort(arr,new Comparator<mo_HoaDonChiTiet>(){
            @Override
            public int compare(mo_HoaDonChiTiet o1, mo_HoaDonChiTiet o2) {
               if(o1.getTongTien()>o2.getTongTien()){
                   return -1;
               }else{
                   return 1;
               }
            }
        });
        fillToTable();
       }
       else if(cb.getSelectedIndex() == 3){
           Collections.sort(arr,new Comparator<mo_HoaDonChiTiet>(){
            @Override
            public int compare(mo_HoaDonChiTiet o1, mo_HoaDonChiTiet o2) {
               if(o1.getTrangThai()>o2.getTrangThai()){
                   return -1;
               }else{
                   return 1;
               }
            }
        });
        fillToTable();
       }
    }//GEN-LAST:event_cbActionPerformed

    private void tkMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tkMouseClicked
        tk.setText("");
        tk.setForeground(Color.BLACK);
    }//GEN-LAST:event_tkMouseClicked

    private void nmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nmActionPerformed

    private void tbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbMouseClicked
        int i =tb.getSelectedRow();
        mpmct.setText(String.valueOf(arr.get(i).getMaPhieuMuonChiTiet()));
         ms.setText(String.valueOf(arr.get(i).getMaSach()));
          mpm.setText(String.valueOf(arr.get(i).getMaPhieuMuon()));
           mpmct.setText(String.valueOf(arr.get(i).getMaPhieuMuonChiTiet()));
         nm.setText(String.valueOf(arr.get(i).getNgayMuon()));
         nt.setText(String.valueOf(arr.get(i).getNgayTra()));
         tt.setText(String.valueOf(arr.get(i).getTongTien()));
         if(arr.get(i).getTrangThai()==1){
             a.setSelected(true);
         }else{
             b.setSelected(true);
         }
    }//GEN-LAST:event_tbMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(view_HoaDonChiTiet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(view_HoaDonChiTiet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(view_HoaDonChiTiet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(view_HoaDonChiTiet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_HoaDonChiTiet().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JRadioButton a;
    public javax.swing.JRadioButton b;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cb;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextField mpm;
    public javax.swing.JTextField mpmct;
    public javax.swing.JTextField ms;
    public javax.swing.JTextField nm;
    public javax.swing.JTextField nt;
    public javax.swing.JPanel p;
    private javax.swing.JTable tb;
    private javax.swing.JTextField tk;
    public javax.swing.JTextField tt;
    // End of variables declaration//GEN-END:variables
}
