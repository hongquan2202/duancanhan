/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author hungl
 */
public class mo_HoaDonChiTiet {
    String maPhieuMuonChiTiet;
    String maPhieuMuon;
    String maSach;
    String ngayMuon;
    String ngayTra;
    int tongTien;
    int trangThai;

    public String getMaPhieuMuonChiTiet() {
        return maPhieuMuonChiTiet;
    }

    public void setMaPhieuMuonChiTiet(String maPhieuMuonChiTiet) {
        this.maPhieuMuonChiTiet = maPhieuMuonChiTiet;
    }

    public String getMaPhieuMuon() {
        return maPhieuMuon;
    }

    public void setMaPhieuMuon(String maPhieuMuon) {
        this.maPhieuMuon = maPhieuMuon;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getNgayMuon() {
        return ngayMuon;
    }

    public void setNgayMuon(String ngayMuon) {
        this.ngayMuon = ngayMuon;
    }

    public String getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(String ngayTra) {
        this.ngayTra = ngayTra;
    }

    public int getTongTien() {
        return tongTien;
    }

    public void setTongTien(int tongTien) {
        this.tongTien = tongTien;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public mo_HoaDonChiTiet(String maPhieuMuonChiTiet, String maPhieuMuon, String maSach, String ngayMuon, String ngayTra,int tongTien, int trangThai) {
        this.maPhieuMuonChiTiet = maPhieuMuonChiTiet;
        this.maPhieuMuon = maPhieuMuon;
        this.maSach = maSach;
        this.ngayMuon = ngayMuon;
        this.ngayTra = ngayTra;
        this.tongTien = tongTien;
        this.trangThai = trangThai;
    }

    public mo_HoaDonChiTiet() {
    }
    
}
