/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author TUAN VU
 */
public class Moder_Sach {
    private int maSach;
    private String tenSach;
    private  int maTacGia;
    private int maTheLoai;
    private int maNhaPhatHanh;
    private int soLuongTon;
    private float giaThue;
    private String viTri;

    public Moder_Sach() {
    }

    public Moder_Sach(int maSach, String tenSach, int maTacGia, int maTheLoai, int maNhaPhatHanh, int soLuongTon, float giaThue, String viTri) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.maTacGia = maTacGia;
        this.maTheLoai = maTheLoai;
        this.maNhaPhatHanh = maNhaPhatHanh;
        this.soLuongTon = soLuongTon;
        this.giaThue = giaThue;
        this.viTri = viTri;
    }

    public int getMaSach() {
        return maSach;
    }

    public void setMaSach(int maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public int getMaTacGia() {
        return maTacGia;
    }

    public void setMaTacGia(int maTacGia) {
        this.maTacGia = maTacGia;
    }

    public int getMaTheLoai() {
        return maTheLoai;
    }

    public void setMaTheLoai(int maTheLoai) {
        this.maTheLoai = maTheLoai;
    }

    public int getMaNhaPhatHanh() {
        return maNhaPhatHanh;
    }

    public void setMaNhaPhatHanh(int maNhaPhatHanh) {
        this.maNhaPhatHanh = maNhaPhatHanh;
    }

    public int getSoLuongTon() {
        return soLuongTon;
    }

    public void setSoLuongTon(int soLuongTon) {
        this.soLuongTon = soLuongTon;
    }

    public float getGiaThue() {
        return giaThue;
    }

    public void setGiaThue(float giaThue) {
        this.giaThue = giaThue;
    }

    public String getViTri() {
        return viTri;
    }

    public void setViTri(String viTri) {
        this.viTri = viTri;
    }
    public Object[] toDaTaRow(){
        return new Object[]{this.getMaSach(),this.getTenSach(),this.getMaTacGia(),this.getMaTheLoai(),this.getMaNhaPhatHanh(),this.getSoLuongTon(),this.getGiaThue(),this.getViTri()};
    }
}
