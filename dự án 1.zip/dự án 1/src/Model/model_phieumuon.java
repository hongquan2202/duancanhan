/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author HONG QUAN
 */
public class model_phieumuon {
    private int maphieumuon;
    private int manhanvien;
    private int makhachhang;
    public model_phieumuon(){
        
    }

    public model_phieumuon(int maphieumuon, int manhanvien, int makhachhang) {
        this.maphieumuon = maphieumuon;
        this.manhanvien = manhanvien;
        this.makhachhang = makhachhang;
    }

    public int getMaphieumuon() {
        return maphieumuon;
    }

    public void setMaphieumuon(int maphieumuon) {
        this.maphieumuon = maphieumuon;
    }

    public int getManhanvien() {
        return manhanvien;
    }

    public void setManhanvien(int manhanvien) {
        this.manhanvien = manhanvien;
    }

    public int getMakhachhang() {
        return makhachhang;
    }

    public void setMakhachhang(int makhachhang) {
        this.makhachhang = makhachhang;
    }
    public Object[] todataRow(){
    return new Object[]{
        this.getMaphieumuon(),this.getManhanvien(),this.getMakhachhang()
    };
}
}
