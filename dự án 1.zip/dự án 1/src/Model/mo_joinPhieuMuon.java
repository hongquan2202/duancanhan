/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author hungl
 */
public class mo_joinPhieuMuon {
    String maPhieuMuon;
    String maPhieuMuonChiTiet;
    String ten;
    String maSach;
    String ngayMuon;
    String ngayTra;
    int trangThai;
    int giaTien;

    public String getMaPhieuMuon() {
        return maPhieuMuon;
    }

    public void setMaPhieuMuon(String maPhieuMuon) {
        this.maPhieuMuon = maPhieuMuon;
    }

    public String getMaPhieuMuonChiTiet() {
        return maPhieuMuonChiTiet;
    }

    public void setMaPhieuMuonChiTiet(String maPhieuMuonChiTiet) {
        this.maPhieuMuonChiTiet = maPhieuMuonChiTiet;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getNgayMuon() {
        return ngayMuon;
    }

    public void setNgayMuon(String ngayMuon) {
        this.ngayMuon = ngayMuon;
    }

    public String getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(String ngayTra) {
        this.ngayTra = ngayTra;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public int getGiaTien() {
        return giaTien;
    }

    public void setGiaTien(int giaTien) {
        this.giaTien = giaTien;
    }

    public mo_joinPhieuMuon(String maPhieuMuon, String maPhieuMuonChiTiet, String ten, String maSach, String ngayMuon, String ngayTra, int trangThai, int giaTien) {
        this.maPhieuMuon = maPhieuMuon;
        this.maPhieuMuonChiTiet = maPhieuMuonChiTiet;
        this.ten = ten;
        this.maSach = maSach;
        this.ngayMuon = ngayMuon;
        this.ngayTra = ngayTra;
        this.trangThai = trangThai;
        this.giaTien = giaTien;
    }

    public mo_joinPhieuMuon() {
    }
    
}
