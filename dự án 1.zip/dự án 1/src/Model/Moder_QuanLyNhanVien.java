/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author TUAN VU
 */
public class Moder_QuanLyNhanVien {
    private int maNhanVien;
    private String taiKhoan;
    private String matKhau;
    private String tenNhanVien;
    private boolean gioiTinh;
    private String ngaySinh;
    private String diaChi;
    private String sdt;
    private String email;
    private boolean vaiTro;

    public Moder_QuanLyNhanVien() {
    }

    public Moder_QuanLyNhanVien(int maNhanVien, String taiKhoan, String matKhau, String tenNhanVien, boolean gioiTinh, String ngaySinh, String diaChi, String sdt, String email, boolean vaiTro) {
        this.maNhanVien = maNhanVien;
        this.taiKhoan = taiKhoan;
        this.matKhau = matKhau;
        this.tenNhanVien = tenNhanVien;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
        this.sdt = sdt;
        this.email = email;
        this.vaiTro = vaiTro;
    }

    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getTaiKhoan() {
        return taiKhoan;
    }

    public void setTaiKhoan(String taiKhoan) {
        this.taiKhoan = taiKhoan;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public String getTenNhanVien() {
        return tenNhanVien;
    }

    public void setTenNhanVien(String tenNhanVien) {
        this.tenNhanVien = tenNhanVien;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(boolean vaiTro) {
        this.vaiTro = vaiTro;
    }
    public Object[] toDaTaRow(){
        return new Object[]{this.getMaNhanVien(),this.getTaiKhoan(),this.getMatKhau(),this.tenNhanVien,this.isGioiTinh()?"Nam":"Nữ",this.getNgaySinh(),this.getDiaChi(),this.getSdt(),this.getEmail(),this.isVaiTro()?"Nhân Viên":"Quản Lý"
        };
    }
}
