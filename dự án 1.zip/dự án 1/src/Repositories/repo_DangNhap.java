/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;
import Model.mo_DangNhap;
import utils.ConnectDB;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import view.View_DangNhap;

/**
 *
 * @author hungl
 */

public class repo_DangNhap {
    public Connection con = null;
    public ResultSet rs = null;
    public PreparedStatement ps = null;
    public String sql = null;
    public ArrayList<mo_DangNhap> arr = new ArrayList<>();
    public ArrayList<mo_DangNhap> duyetSql(){     
        try {
            sql = "select taiKhoan,matKhau,tenNhanVien,vaiTro from NhanVien";
            con = ConnectDB.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                String taiKhoan = rs.getString("taiKhoan");
                String matKhau = rs.getString("matKhau");
                String ten = rs.getString("tenNhanVien");
                int vaiTro = rs.getInt("vaiTro");
                mo_DangNhap mo = new mo_DangNhap(taiKhoan,matKhau,ten,vaiTro);
                arr.add(mo);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(repo_DangNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arr;
    }
    
   
}
