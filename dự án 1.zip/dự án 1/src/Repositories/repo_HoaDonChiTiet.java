/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;

import Model.mo_DangNhap;
import Model.mo_HoaDonChiTiet;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.ConnectDB;
import view.view_HoaDonChiTiet;

/**
 *
 * @author hungl
 */
public class repo_HoaDonChiTiet {
    
    public Connection con = null;
    public ResultSet rs = null;
    public PreparedStatement ps = null;
    public String sql = null;
    public ArrayList<mo_HoaDonChiTiet> arr = new ArrayList<>();
    public ArrayList<mo_HoaDonChiTiet> duyetSql(){     
        
        try {
            
            sql = "select * from phieuMuonChiTiet";
            con = ConnectDB.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            arr.clear();
            while(rs.next()){           
                mo_HoaDonChiTiet mo = new mo_HoaDonChiTiet();    
                mo.setMaPhieuMuonChiTiet(rs.getString(1));
                mo.setMaPhieuMuon(rs.getString(2));
                mo.setMaSach(rs.getString(3));
                mo.setNgayMuon(rs.getString(4));
                mo.setNgayTra(rs.getString(5));
                mo.setTongTien(rs.getInt(6));
                mo.setTrangThai(rs.getInt(7));
                arr.add(mo);
            }
            
        } catch (SQLException ex) {
            
        }
        return arr;
        
    }
    public String TimKiem(String a){
        for(int i = 0;i<arr.size();i++){
            if(a.equals(arr.get(i).getMaPhieuMuonChiTiet())){
                String b = arr.get(i).getMaPhieuMuonChiTiet();
                 String c = arr.get(i).getMaPhieuMuon();
                 String d = arr.get(i).getMaSach();
                 String e = arr.get(i).getNgayMuon();
                 String f = arr.get(i).getNgayTra();
                 float g = arr.get(i).getTongTien();
                 int h = arr.get(i).getTrangThai();
            }
        }
        return "k tim thay phieu muon";
    }
    
}
