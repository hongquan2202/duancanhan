/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;
import utils.DBConnext;
import java.sql.*;
import Model.Moder_KhachHang;
import java.util.ArrayList;
/**
 *
 * @author TUAN VU
 */
public class Repositories_KhachHang {
       private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;
    
  public ArrayList<Moder_KhachHang>getAll(){
        sql="select * from KhachHang";
        ArrayList<Moder_KhachHang> list=new ArrayList<>();
        try {
          con=DBConnext.getConnection();
          ps=con.prepareStatement(sql);
          rs=ps.executeQuery();
            while (rs.next()) {                
                Moder_KhachHang khachhang= new Moder_KhachHang();
                khachhang.setMaKhachHang(rs.getInt(1));
                khachhang.setTenKhachHang(rs.getString(2));
                khachhang.setGioiTinh(rs.getBoolean(3));
                khachhang.setNgaySinh(rs.getString(4));
                khachhang.setDiaChi(rs.getString(5));
                khachhang.setSdt(rs.getString(6));
                khachhang.setEmail(rs.getString(7));
                list.add(khachhang);
            }
      } catch (Exception e) {
      }
        return list;
    }
  public int them(Moder_KhachHang khachHang){
      sql="insert into KhachHang(maKhachHang,tenKhachHang,gioiTinh,ngaySinh,diaChi,sdt,email) values(?,?,?,?,?,?,?) ";
      try {
          con=DBConnext.getConnection();
          ps=con.prepareStatement(sql);
          ps.setObject(1, khachHang.getMaKhachHang());
          ps.setObject(2, khachHang.getTenKhachHang());
          ps.setObject(3, khachHang.isGioiTinh());
          ps.setObject(4, khachHang.getNgaySinh());
          ps.setObject(5, khachHang.getDiaChi());
          ps.setObject(6, khachHang.getSdt());
          ps.setObject(7, khachHang.getEmail());
          return ps.executeUpdate();
      } catch (Exception e) {
      }
      return 0;
  }
  public int sua(Moder_KhachHang khachHang){
      sql ="update KhachHang set tenKhachHang=?,gioiTinh=?,ngaySinh=?,diaChi=?,sdt=?,email=? where maKhachHang=?";
       try {
          con=DBConnext.getConnection();
          ps=con.prepareStatement(sql);
          ps.setObject(7, khachHang.getMaKhachHang());
          ps.setObject(1, khachHang.getTenKhachHang());
          ps.setObject(2, khachHang.isGioiTinh());
          ps.setObject(3, khachHang.getNgaySinh());
          ps.setObject(4, khachHang.getDiaChi());
          ps.setObject(5, khachHang.getSdt());
          ps.setObject(6, khachHang.getEmail());
          return ps.executeUpdate();
      } catch (Exception e) {
      }
      return 0;
  }
  public int xoa(Moder_KhachHang khachHang){
      sql="delete from PhieuMuon where maKhachHang=? delete from KhachHang where maKhachHang=?";
       try {
          con=DBConnext.getConnection();
          ps=con.prepareStatement(sql);
          ps.setObject(1, khachHang.getMaKhachHang());    
           ps.setObject(2, khachHang.getMaKhachHang()); 
          return ps.executeUpdate();
      } catch (Exception e) {
      }
      return 0;
  }
  public ArrayList<Moder_KhachHang>timKiem(String tenCanTim){
      sql="select * from KhachHang where tenKhachHang like ?";
      ArrayList<Moder_KhachHang> list_kh=new ArrayList<>();
      try {
          con=DBConnext.getConnection();
          ps=con.prepareStatement(sql);
          ps.setObject(1, '%'+tenCanTim+'%');
          rs=ps.executeQuery();
          while (rs.next()) {              
                 Moder_KhachHang khachhang= new Moder_KhachHang();
                khachhang.setMaKhachHang(rs.getInt(1));
                khachhang.setTenKhachHang(rs.getString(2));
                khachhang.setGioiTinh(rs.getBoolean(3));
                khachhang.setNgaySinh(rs.getString(4));
                khachhang.setDiaChi(rs.getString(5));
                khachhang.setSdt(rs.getString(6));
                khachhang.setEmail(rs.getString(7));
                list_kh.add(khachhang);
          }
      } catch (Exception e) {
      }
      return list_kh;
      }
  
  
}
