/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;

import utils.DBConnext;
import java.sql.*;
import Model.Moder_Sach;
import java.util.ArrayList;

/**
 *
 * @author TUAN VU
 */
public class Repositories_Sach {

    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;

    public ArrayList<Moder_Sach> getAll() {
        sql = "select * from Sach";
        ArrayList<Moder_Sach> list = new ArrayList<>();
        try {
            con = DBConnext.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Moder_Sach sach = new Moder_Sach();
                sach.setMaSach(rs.getInt(1));
                sach.setTenSach(rs.getString(2));
                sach.setMaTacGia(rs.getInt(3));
                sach.setMaTheLoai(rs.getInt(4));
                sach.setMaNhaPhatHanh(rs.getInt(5));
                sach.setSoLuongTon(rs.getInt(6));
                sach.setGiaThue(rs.getFloat(7));
                sach.setViTri(rs.getString(8));
                list.add(sach);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public int them(Moder_Sach sach) {
        sql = "insert into Sach(maSach,tenSach,maTacGia,maTheLoai,maNhaPhatHanh,soLuongTon,giaThue,vitri) values (?,?,?,?,?,?,?,?)";
        try {
            con = DBConnext.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, sach.getMaSach());
            ps.setObject(2, sach.getTenSach());
            ps.setObject(3, sach.getMaTacGia());
            ps.setObject(4, sach.getMaTheLoai());
            ps.setObject(5, sach.getMaNhaPhatHanh());
            ps.setObject(6, sach.getSoLuongTon());
            ps.setObject(7,sach.getGiaThue());
            ps.setObject(8, sach.getViTri());
            return ps.executeUpdate();
        } catch (Exception e) {
        }
        return 0;
    }
    public int sua(Moder_Sach sach){
        sql="update Sach set tenSach=?,maTacGia=?,maTheLoai=?,maNhaPhatHanh=?,soLuongTon=?,giaThue=?,vitri=? where maSach=?";
        try {
            con = DBConnext.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(8, sach.getMaSach());
            ps.setObject(1, sach.getTenSach());
            ps.setObject(2, sach.getMaTacGia());
            ps.setObject(3, sach.getMaTheLoai());
            ps.setObject(4, sach.getMaNhaPhatHanh());
            ps.setObject(5, sach.getSoLuongTon());
            ps.setObject(6,sach.getGiaThue());
            ps.setObject(7, sach.getViTri());
            return ps.executeUpdate();
        } catch (Exception e) {
        }
        return 0;
    }
    public int xoa (Moder_Sach sach ){
        sql="delete from PhieuMuonChiTiet where maSach =? delete from Sach where maSach =?";
        try {
            con = DBConnext.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, sach.getMaSach());
               ps.setObject(2, sach.getMaSach());
           
            return ps.executeUpdate();
        } catch (Exception e) {
        }
        return 0;
    }
    public ArrayList<Moder_Sach>timKiem(String tenCanTim){
        sql="select * from Sach where tenSach like ? ";
        ArrayList<Moder_Sach> lis_Sach= new ArrayList<>();
        try {
            con= DBConnext.getConnection();
             ps=con.prepareStatement(sql);
          ps.setObject(1, '%'+tenCanTim+'%');
          rs=ps.executeQuery();
            while (rs.next()) {                
                Moder_Sach sach = new Moder_Sach();
                  sach.setMaSach(rs.getInt(1));
                sach.setTenSach(rs.getString(2));
                sach.setMaTacGia(rs.getInt(3));
                sach.setMaTheLoai(rs.getInt(4));
                sach.setMaNhaPhatHanh(rs.getInt(5));
                sach.setSoLuongTon(rs.getInt(6));
                sach.setGiaThue(rs.getFloat(7));
                sach.setViTri(rs.getString(8));
                lis_Sach.add(sach);
            }
        } catch (Exception e) {
        }
        return lis_Sach;
    }
}

