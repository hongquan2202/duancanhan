/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;

import Model.mo_HoaDonChiTiet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import utils.ConnectDB;
import Model.mo_joinPhieuMuon;

/**
 *
 * @author hungl
 */
public class repo_joinPhieuMuon {
     
    public Connection con = null;
    public ResultSet rs = null;
    public PreparedStatement ps = null;
    public String sql = null;
    public ArrayList<mo_joinPhieuMuon> arr = new ArrayList<>();
    public ArrayList<mo_joinPhieuMuon> Join(){     
        
        try {
            
            sql = "select PhieuMuonChiTiet.maPhieuMuonChiTiet,PhieuMuon.maPhieuMuon, KhachHang.tenKhachHang, NhanVien.tenNhanVien,PhieuMuonChiTiet.ngayMuon,PhieuMuonChiTiet.ngayTra,PhieuMuonChiTiet.trangThai,PhieuMuonChiTiet.giaTien from PhieuMuon\n" +
"join KhachHang on PhieuMuon.maKhachHang = KhachHang.maKhachHang\n" +
"join PhieuMuonChiTiet on PhieuMuonChiTiet.maPhieuMuon = PhieuMuon.maPhieuMuon\n" +
"join NhanVien on PhieuMuon.maNhanVien =NhanVien.maNhanVien";
            con = ConnectDB.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            arr.clear();
            while(rs.next()){           
                mo_joinPhieuMuon mo = new mo_joinPhieuMuon();    
                mo.setMaPhieuMuonChiTiet(rs.getString(1));
                mo.setMaPhieuMuon(rs.getString(2));
                mo.setTen(rs.getString(3));
                mo.setMaSach(rs.getString(4));
                mo.setNgayMuon(rs.getString(5));
                mo.setNgayTra(rs.getString(6));
                mo.setGiaTien(rs.getInt(8));
                mo.setTrangThai(rs.getInt(7));
                arr.add(mo);
            }
            
        } catch (SQLException ex) {
            
        }
        return arr;
        
    }
}
