/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;
import utils.DBConnect;
import java.sql.*;
import java.util.ArrayList;
import Model.model_phieumuon;
/**
 *
 * @author HONG QUAN
 */
public class Repository_phieumuon {
    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;
    public ArrayList<model_phieumuon> getAll(){
        sql = " select maPhieuMuon,maNhanVien,maKhachHang from PhieuMuon";
        ArrayList<model_phieumuon> listphieumuon = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {                
                model_phieumuon phieumuon = new model_phieumuon();
                phieumuon.setMaphieumuon(rs.getInt(1));
                phieumuon.setManhanvien(rs.getInt(2));
                phieumuon.setMakhachhang(rs.getInt(3));
                listphieumuon.add(phieumuon);
                
            }
            return listphieumuon;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public int them(model_phieumuon ph){
        sql = "insert into PhieuMuon ( maPhieuMuon,maNhanVien,maKhachHang) values (?,?,?)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ph.getMaphieumuon());
            ps.setObject(2, ph.getManhanvien());
            ps.setObject(3, ph.getMakhachhang());
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("loi"+e);
            return 0;
        }
    }
    public int xoa(model_phieumuon ph){
        sql = " delete from PhieuMuonChiTiet where maPhieuMuon =? delete from PhieuMuon where maPhieuMuon= ?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, ph.getMaphieumuon());
             ps.setObject(2, ph.getMaphieumuon());
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("loi"+e);
            return 0;
        }
    }
    public int sua(model_phieumuon ph){
        sql = "update PhieuMuon set maNhanVien=?, maKhachHang=? where maPhieuMuon=?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(3, ph.getMaphieumuon());
            ps.setObject(1, ph.getManhanvien());
            ps.setObject(2, ph.getMakhachhang());
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("loi"+e);
            return 0;
        }
    }
    public ArrayList<model_phieumuon> timkiem(String macantim){
        sql = "select maPhieuMuon,maNhanVien,maKhachHang from PhieuMuon where maPhieuMuon like?";
        ArrayList< model_phieumuon> listph = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, '%'+macantim+'%');
            rs = ps.executeQuery();
            while (rs.next()) {                
                int maPhieuMuon;
                int maNhanVien;
                int maKhachHang;
                maPhieuMuon = rs.getInt(1);
                maNhanVien = rs.getInt(2);
                maKhachHang = rs.getInt(3);
                model_phieumuon ph = new model_phieumuon(maPhieuMuon, maNhanVien, maKhachHang);
                listph.add(ph);
            }
            return listph;
        } catch (Exception e) {
            return null;
        }
    }
}
