/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;
import utils.DBConnext;
import java.sql.*;
import Model.Moder_QuanLyNhanVien;
import java.util.ArrayList;
/**
 *
 * @author TUAN VU
 */
public class Repositories_QuanLyNhanVien {
      private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;
    public ArrayList<Moder_QuanLyNhanVien>getAll(){
        sql="select * from NhanVien";
        ArrayList<Moder_QuanLyNhanVien> list= new ArrayList<>();
        try {
            con= DBConnext.getConnection();
            ps= con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {                
                Moder_QuanLyNhanVien nv= new Moder_QuanLyNhanVien();
                nv.setMaNhanVien(rs.getInt(1));
                nv.setTaiKhoan(rs.getString(2));
                nv.setMatKhau(rs.getString(3));
                nv.setTenNhanVien(rs.getString(4));
                nv.setGioiTinh(rs.getBoolean(5));
                nv.setNgaySinh(rs.getString(6));
                nv.setDiaChi(rs.getString(7));
                nv.setSdt(rs.getString(8));
                nv.setEmail(rs.getString(9));
                nv.setVaiTro(rs.getBoolean(10));
                list.add(nv);
            }
        } catch (Exception e) {
        }
        return list;
    }
    public int them(Moder_QuanLyNhanVien nv){
        sql="insert into NhanVien(maNhanVien,taiKhoan,matKhau,tenNhanVien,gioiTinh,ngaySinh,diaChi,sdt,email,vaiTro) values(?,?,?,?,?,?,?,?,?,?)";
        try {
            con =DBConnext.getConnection();
            ps=con.prepareCall(sql);
            ps.setObject(1, nv.getMaNhanVien());
            ps.setObject(2, nv.getTaiKhoan());
            ps.setObject(3, nv.getMatKhau());
            ps.setObject(4, nv.getTenNhanVien());
            ps.setObject(5, nv.isGioiTinh());
            ps.setObject(6, nv.getNgaySinh());
            ps.setObject(7, nv.getDiaChi());
            ps.setObject(8, nv.getSdt());
            ps.setObject(9, nv.getEmail());
            ps.setObject(10, nv.isVaiTro());
            return ps.executeUpdate();
        } catch (Exception e) {
        }
        return 0;
   
}
    public int sua(Moder_QuanLyNhanVien nv){
        sql="update NhanVien set taiKhoan=?,matKhau=?,tenNhanVien=?,gioiTinh=?,ngaySinh=?,diaChi=?,sdt=?,email=?,vaiTro=? where maNhanVien=?";
        try {
            con =DBConnext.getConnection();
            ps=con.prepareCall(sql);
            ps.setObject(10, nv.getMaNhanVien());
            ps.setObject(1, nv.getTaiKhoan());
            ps.setObject(2, nv.getMatKhau());
            ps.setObject(3, nv.getTenNhanVien());
            ps.setObject(4, nv.isGioiTinh());
            ps.setObject(5, nv.getNgaySinh());
            ps.setObject(6, nv.getDiaChi());
            ps.setObject(7, nv.getSdt());
            ps.setObject(8, nv.getEmail());
            ps.setObject(9, nv.isVaiTro());
            return ps.executeUpdate();
        } catch (Exception e) {
        }
        return 0;
   
}
    public ArrayList<Moder_QuanLyNhanVien> timKiem(String tenCanTim){
        sql="select * from NhanVien where tenNhanVien like ?";
        ArrayList<Moder_QuanLyNhanVien> list_nv= new ArrayList<>();
        try {
             con=DBConnext.getConnection();
          ps=con.prepareStatement(sql);
          ps.setObject(1, '%'+tenCanTim+'%');
          rs=ps.executeQuery();
            while (rs.next()) {                
                Moder_QuanLyNhanVien nv= new Moder_QuanLyNhanVien();
                nv.setMaNhanVien(rs.getInt(1));
                nv.setTaiKhoan(rs.getString(2));
                nv.setMatKhau(rs.getString(3));
                nv.setTenNhanVien(rs.getString(4));
                nv.setGioiTinh(rs.getBoolean(5));
                nv.setNgaySinh(rs.getString(6));
                nv.setDiaChi(rs.getString(7));
                nv.setSdt(rs.getString(8));
                nv.setEmail(rs.getString(9));
                nv.setVaiTro(rs.getBoolean(10));
                list_nv.add(nv);
            }
        } catch (Exception e) {
        }
        return list_nv;
    }
    public int xoa(Moder_QuanLyNhanVien nv){
        sql="delete from PhieuMuon where maNhanVien =? delete from NhanVien where maNhanVien=?";
         try {
            con =DBConnext.getConnection();
            ps=con.prepareCall(sql);
            ps.setObject(1, nv.getMaNhanVien());
             ps.setObject(2, nv.getMaNhanVien());
            return ps.executeUpdate();
        } catch (Exception e) {
        }
        return 0;
    }
}
